<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AuctionHistoryController extends Controller
{
    //
}
