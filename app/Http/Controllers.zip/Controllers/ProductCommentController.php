<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProductCommentController extends Controller
{
    //
}
