<html>
  <head>

    <meta http-equiv="content-type" content="text/html; ">
  </head>
  <body>
    <br>
      <br>
      <br>
      Woodyオークションに参加いただきありがとうございます。
      <br>
      <br>

      パスワードを取得するには、以下のリンクをクリックしてください
      <br>
      <br>
      <a href="{{$data['url']}}">オークションパスワードを変更するにはこちらをクリックしてください。</a>
      <br>
      <br>
      ご不明な点は下記にお問い合わせください。<br>
      <br>
      =====================================================<br>
      有限会社ウッディー<br>
      電話番号: 03-5700-4622<br>
      FAX番号 : 03-5700-4625<br>
      URL : <a class="moz-txt-link-freetext" href="https://auction.woodyengineering.com/">https://auction.woodyengineering.com/</a><br>
      E-Mail: <a class="moz-txt-link-abbreviated" href="mailto:info@woodyengineering.com">info@woodyengineering.com</a><br>
      =====================================================<br>
    
  </body>
</html>