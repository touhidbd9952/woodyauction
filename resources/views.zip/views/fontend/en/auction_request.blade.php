@extends('layouts.fontend_master2')

@section('content')

<style>
    .red{color: red;padding-left:10px;}
    .addnew{cursor: pointer;color: blue;text-decoration: underline;}
    .form-control:focus {border-color: red;}
    .form-group label{text-align: right !important;}
</style>    

<section class="section section-md bg-white">
    <div class="shell shell-wide wow fadeInUpSmall divsize" data-wow-offset="150" style="margin-left: 0px;margin-right:0px;">
    <div class="cat-items-grid">
    <section id="home" class="home-page-content page-content">
        <section class="products-section">

<div class="container">
    <div class="row">
        <div class="col-md-12">
            
            <div class="card">
                <div class="card-header">
                    <h4 class="headerstyle">Auction Product Entry Request</h4>
                    <p>
                        
                        If you want to sale your machine on our auction, please send machine information to us by mail. <br>
                        write a mail with machine information in details (write about all the problems that help to <br>
                        bidder to know it properly) like below way. Add all photos of machine in a folder, make it zip file.
                        <br>
                        Send mail with zip photos file to "info@woodyltd.com"
                        <br>
                        <br>
                        <br>
                        Mail Subject: 出品依頼　SUMITOMO 21-FD45PVII #D4E-00376
                        <br>
                        <br>

                        Maker  : SUMITOMO <br>
                        Model  :  21-FD45PVII <br>
                        Serial No. : D4E-00376<br>
                        YEAR  : 2000<br>
                        HOUR : 17124<br>
                        TIRE FRONT : 300-15 18PR<br>
                        REAR : 7.00-12-12PR<br>
                        3M FULL FREE MAST<br>
                        FORK LENGTH : 2350mm<br>
                        最大荷重 : 4000kg<br>
                        サイドブレーキ　少し弱い<br><br>

                        ヤード渡し　120万スタート<br>

                        <br>
                        <br>
                        ****Please must send zip photos file with mail attachment****
                    </p>
                    <br>
                    
                    
                    
                </div>

                <div class="card-body">
                    
                    
                    
                    
                   
                    

                    

                </div>
            </div>

        </div>
    </div>
</div>

        </section>
    </section>
    </div>
    </div>
</section>



@endsection


