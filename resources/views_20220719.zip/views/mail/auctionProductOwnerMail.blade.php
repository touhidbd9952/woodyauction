<html>
  <head>

    <meta http-equiv="content-type" content="text/html; ">
  </head>
  <body>
    <br>
      <br>
      <br>
      {{$auctiondata['companyname']}}<br>    
      {{$auctiondata['person_incharge']}} &nbsp;様<br>
      ID &nbsp;:&nbsp;{{$auctiondata['wonercode']}}<br>
      <br>
        この度はご出展ありがとうございます。<br>
        貴社出展機械の成約結果は以下の通りとなります。<br>
        ※後日「オークション委託機械支払明細書」をFAXにて送付させて頂きますので宜しくお願い致します。<br>

      <br>
      /_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/<br>
      <br>
      【成約】
      <br>

      <?php 
        echo $auctiondata['auctionsolddata'];
      ?>
     
      
     <br>
     <br>
     <br>
      /_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/<br>
      <br><br>
      

      ご不明な点は下記にお問い合わせください。<br>
      <br>
      =====================================================<br>
      有限会社ウッディー<br>
      電話番号: 03-5700-4622<br>
      FAX番号 : 03-5700-4625<br>
      URL : <a class="moz-txt-link-freetext" href="https://auction.woodyengineering.com/">https://auction.woodyengineering.com/</a><br>
      E-Mail: <a class="moz-txt-link-abbreviated" href="mailto:info@woodyengineering.com">info@woodyengineering.com</a><br>
      =====================================================<br>
    
  </body>
</html>